const arrStr = ['#javascript', '#webdev', '#beginner', '#react', '#tutorial', '#java', '#python', '#programming', '#css', '#html', '#devops', '#productivity'];

arrStr.map(elm => {
    const selectionDiv = document.createElement('div');
    selectionDiv.classList.add('selection');
    selectionDiv.classList.add('hover-effect');

    selectionDiv.innerHTML += `<a href=''>${elm}</a>`;
    selectionDiv.innerHTML += `<button class='btn btn-sm bg-primary text-light ml-auto'>Follow</button>`;

    const tagContainer = document.getElementById('tag-container');
    tagContainer.appendChild(selectionDiv);
});

const optionListSecondNavbar = document.getElementsByClassName('check-active');

for (let i = 0; i < optionListSecondNavbar.length; i++){
    optionListSecondNavbar[i].addEventListener('click', (e) => {
        const current = document.getElementsByClassName('active');
        current[0].className = current[0].className.replace(' active', '');
        e.target.className += ' active';
    });
};




